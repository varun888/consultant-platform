
import React from 'react';
import { FaFacebookF, FaInstagram, FaLinkedinIn, FaTwitter } from 'react-icons/fa';
import Slider from 'react-slick';
import { Col, Container, Row, } from 'reactstrap';
import './style.css';
import GoogleMapReact from 'google-map-react';

export const Contactus = () => {
    var settings = {

    };


    return (
        <>
            <div className="banner_section">
                <Row>
                    <Col className="banner_image_left" md="10" sm="12">
                        <Slider {...settings}>
                            <img src="images/banner_image.jpg" alt="" />
                            <img src="images/banner_image.jpg" alt="" />
                            <img src="images/banner_image.jpg" alt="" />
                            <img src="images/banner_image.jpg" alt="" />
                            <img src="images/banner_image.jpg" alt="" />
                        </Slider>
                    </Col>

                    <Col md="2" sm="12">
                        <div className="icons_banner">
                            <a className="banner_social_icon" href="facebook"><FaFacebookF /></a>
                            <a className="banner_social_icon" href="linkedin"><FaLinkedinIn /></a>

                            <a className="banner_social_icon" href="twitter"><FaTwitter /></a>

                            <a className="banner_social_icon" href="instagram"><FaInstagram /></a>
                        </div>
                    </Col>
                </Row>
            </div>

            <div className="map_contact_us_page">
                <Container>
                    <div>
                        <Row>
                            <Col className="map_section" md="12">
                                <img src="images/map.png" alt="" />
                            </Col>
                        </Row>
                    </div>
                </Container>
            </div>


        </>
    )
}